@bot.on(events.NewMessage(pattern="/start"))
async def menu(event):
	inline = [
[Button.url("< ADMIN PANEL >>","menu")],
[Button.url("[ TELEGRAM ]","https://t.me/wingsofhope"),

		msg = f"""
** ⚡ WELCOME TO WINGS VPN ⚡ **
"""
await event.reply(msg,buttons=inline)